import { SignOutButton } from "@clerk/nextjs";

export default function SignOutButton() {
  return (
   
      <SignOutButton />
   
  );
}